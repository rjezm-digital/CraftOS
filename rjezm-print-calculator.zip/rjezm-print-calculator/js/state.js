window.currentUser = null;

window.materials = [];
window.inkMaterials = [];
window.costingItems = [];
window.products = [];

window.lastInkCost = 0;
window.lastElecCost = 0;

window.lastInkUsage = { c:0, m:0, y:0, k:0 };