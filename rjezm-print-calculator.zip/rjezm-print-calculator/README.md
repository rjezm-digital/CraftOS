# RJEZM DIGITAL – Print Cost Calculator

Pure Firebase version  
No SDK  
GitHub Pages compatible  

## How to Deploy
1. Upload to GitHub
2. Enable Pages
3. Done